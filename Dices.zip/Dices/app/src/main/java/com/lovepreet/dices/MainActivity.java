// Name: Lovepreet Kaur
// Student ID : A00238391
package com.lovepreet.dices;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner sp_die, sp_unit;

    private String[] arrayList_die = {"Choose a die to roll","4 Sided Die","6 Sided Die","8 Sided Die","10 Sided Die","12 Sided Die","20 Sided Die"};
    private TextView choice, upside;
    private Button roll, rollagain;
    private LinearLayout layout, buttonLayout, layout1;
    int maxValue;
    int randomValue;
    int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getUiObject();
        setSpinner();




        roll.setOnClickListener(new View.OnClickListener()

        {
            @SuppressLint("DefaultLocale")
            @Override
            public void onClick (View v){
                int selectedId = sp_die.getSelectedItemPosition();

                if (selectedId == 1) {
                    maxValue = 4;
                } else if (selectedId == 2) {
                    maxValue = 6;
                } else if (selectedId == 3) {
                    maxValue = 8;
                } else if (selectedId == 4) {
                    maxValue = 10;
                } else if (selectedId == 5) {
                    maxValue = 12;
                } else if (selectedId == 6) {
                    maxValue = 20;
                }
                randomValue = (int) (Math.random() * maxValue) + 1;
                upside.setText(String.format("%d is your Upside number !! ", randomValue));
            }
        });
        rollagain.setOnClickListener(new View.OnClickListener()

        {
            @SuppressLint("DefaultLocale")
            @Override
            public void onClick (View v){
                int selectedId = sp_die.getSelectedItemPosition();

                if (selectedId == 1) {
                    maxValue = 4;
                } else if (selectedId == 2) {
                    maxValue = 6;
                } else if (selectedId == 3) {
                    maxValue = 8;
                } else if (selectedId == 4) {
                    maxValue = 10;
                } else if (selectedId == 5) {
                    maxValue = 12;
                } else if (selectedId == 6) {
                    maxValue = 20;
                }
                randomValue = (int) (Math.random() * maxValue) + 1;
                upside.setText(String.format(" Now!! %d is Your Upside   ", randomValue));
            }
        });
    }
    private void setSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, arrayList_die);
        sp_die.setAdapter(adapter);
        sp_die.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
    }

    private void getUiObject() {
        choice = findViewById(R.id.display_choice);
        upside = findViewById(R.id.upside);
        layout = findViewById(R.id.linSecond);
        layout1 = findViewById(R.id.layout1);
        roll = findViewById(R.id.roll);
        rollagain = findViewById(R.id.rollagain);
        sp_die = findViewById(R.id.sp_die);
        buttonLayout = findViewById(R.id.buttonlayout);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (position == 0) {

            layout1.setVisibility(View.INVISIBLE);
            layout.setVisibility(View.INVISIBLE);
            buttonLayout.setVisibility(View.INVISIBLE);
            choice.setText("");
            upside.setText("");
        }

            if (position == 1) {
                layout1.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.VISIBLE);
                choice.setText("let's roll 4 sided dice");
                upside.setText("");

            } else if (position == 2) {
                layout1.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.VISIBLE);
                choice.setText("let's roll 6 sided dice");
                upside.setText("");

            } else if (position == 3) {

                layout1.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.VISIBLE);
                choice.setText("let's roll 8 sided dice");
                upside.setText("");

            } else if (position == 4) {

                layout1.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.VISIBLE);
                choice.setText("let's roll 10 sided dice");
                upside.setText("");

            } else if (position == 5) {
                layout1.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.VISIBLE);
                choice.setText("let's roll 12 sided dice");
                upside.setText("");

            } else if (position == 6) {
                layout1.setVisibility(View.VISIBLE);
                layout.setVisibility(View.VISIBLE);
                buttonLayout.setVisibility(View.VISIBLE);
                choice.setText("let's roll 20 sided dice");
                upside.setText("");

            }
        }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menus, menu);
        return true;
    }


}

